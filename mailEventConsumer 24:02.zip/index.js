const { receiveMessages } = require('./app/controller')

exports.handler = function (event, context, callback) {
    context.callbackWaitsForEmptyEventLoop = false;
    receiveMessages(event, callback);
};

