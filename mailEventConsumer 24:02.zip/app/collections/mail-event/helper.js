var MongoClient = require("mongodb").MongoClient
// const databaseName = "develop",
// collectionName = "sourabh"

// let db = null;
// const uri = `mongodb://developer:zvFB8d6L11r^lW@development-shard-00-00-czols.mongodb.net:27017,development-shard-00-01-czols.mongodb.net:27017,development-shard-00-02-czols.mongodb.net:27017/develop?ssl=true&replicaSet=Development-shard-0&authSource=admin&retryWrites=true&w=majority`;
var databaseName = "develop", collectionName = "sourabh";
class MailEventHelper {

  validateMailEvent(data) {
    return data;
  }

  processMailEvent(data) {
    var obj = data;
    console.log("obj is ",typeof obj);
    var record = JSON.parse(obj.Message);

    console.log("obj records is",record)
    // var mailEventObject = new MailEvent();
    // data = JSON.parse(data);
    // return mailEventObject;
     //For all
     //var messageId = JSON.parse(obj.MessageId);
     var notificationType = record.notificationType;
     //for mail
     var destination = record.mail["destination"];
     var source = record.mail.source;
     var sourceIp = record.mail.sourceIp;
     var timestamp = record.mail.timestamp;
     //bounce case variables
     if(record.bounce){
     var bounceType = record.bounce.bounceType;
     var bouncedRecipients = record.bounce.bouncedRecipients[0].emailAddress; //emailaddress of bounced id
     var action = record.bounce.bouncedRecipients[0].action;
     var status =record.bounce.bouncedRecipients[0].status;
     var diagnosticCode = record.bounce.bouncedRecipients[0].diagnosticCode;
     
     }
     var myobj = {  notificationType: notificationType, destination: destination, source: source, sourceIp: sourceIp, timestamp:timestamp, bounceType: bounceType, bouncedRecipients: bouncedRecipients, action: action, status: status, diagnosticCode: diagnosticCode};//added
     console.log("myobj is ",myobj);
     return myobj;

     
}

// async insertMailEvent(mailEventBody) {
//     try {
//       this.validateMailEvent(mailEventBody);
//       const processedMailEvent = this.processMailEvent(data);
//       //return MailEventService.insertOne(processedMailEvent);
//       context.callbackWaitsForEmptyEventLoop = false;
//       return createDoc(databaseName, collectionName, processedMailEvent);
//     } catch (error) {
//       console.log(error);
//       return Promise.reject(error);
//     }
//   }

  insertMailEvent(mailEventBody) {
    try {
      this.validateMailEvent(mailEventBody);
      const processedMailEvent = this.processMailEvent(mailEventBody);
      return this.createDoc(databaseName, collectionName, processedMailEvent);
    }
    catch (error) {
      console.log(error);
    }
  }


  async createDoc(databaseName, collectionName, myobj) {

    let db = null;
    const uri = "mongodb://developer:zvFB8d6L11r^lW@development-shard-00-00-czols.mongodb.net:27017,development-shard-00-01-czols.mongodb.net:27017,development-shard-00-02-czols.mongodb.net:27017/develop?ssl=true&replicaSet=Development-shard-0&authSource=admin&retryWrites=true&w=majority";
    var isConnected = db && db.serverConfig.isConnected()
    if (isConnected) {
      console.log(`Already connected to database ${databaseName}!`)
    } else {
      console.log(`Connecting to database (cold start)`)
      var client = await MongoClient.connect(uri, { useNewUrlParser: true })
      db = client.db(databaseName)
    }

    var result = await db.collection(collectionName).insertOne(myobj)
    console.log(`Just created an entry into ${collectionName} Collection with ID: ${result.insertedId}`)
    return result
  }
}


module.exports = new MailEventHelper();

