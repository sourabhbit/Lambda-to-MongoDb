const MailEventHelper = require('./helper');

class MailEventController {


    async insertMailEvent(mailEventBody) {
        try{
            let addedMailEvent = await MailEventHelper.insertMailEvent(mailEventBody);
            return Promise.resolve(addedMailEvent);
        }
        catch(error){
            return Promise.reject(error);
        }
    }

    async createDoc(databaseName, collectionName, myobj) {
        var isConnected = db && db.serverConfig.isConnected()
        if (isConnected) {
            log(`Already connected to database ${databaseName}!`)
        } else {
            log(`Connecting to database (cold start)`)
            var client = await MongoClient.connect(uri)
            db = client.db(databaseName)
        }
      
        var result = await db.collection(collectionName).insertOne(myobj)
        log(`Just created an entry into ${collectionName} Collection with ID: ${result.insertedId}`)
        return result
      }

}

module.exports = new MailEventController();