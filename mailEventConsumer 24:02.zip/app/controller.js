const SQSAdapter = require('./adapters/SQS');
const MailEventController = require('./collections/mail-event/controller');

async function deleteMessage(message) {
    try {
        let params = {
            QueueUrl: process.env.TASK_QUEUE_URL,
            ReceiptHandle: message.ReceiptHandle
        };
        const response = await SQSAdapter.deleteMessage(params);
        console.log('deleteMessage Success');
        return Promise.resolve(response);
    }
    catch (error) {
        console.log('deleteMessages Error');
        console.log(error);
        return Promise.reject(error);
    }
}

async function receiveMessages(event) {
    try {
        console.log('receiveMessages Success');
        await handleMessages(event);
        return Promise.resolve();
    }
    catch (error) {
        console.log('receiveMessages Error');
        console.log(error);
        return Promise.reject(error);
    }

}

function processMessage(message) {
    let body;
    if (message && message.Body) {
        body = message.Body;
        
        try{
            body = JSON.parse(body);
        } catch (error) {
            body = "\""+body+"\"";
            try{
                body = JSON.parse(body);
            } catch(error) {
                console.log('body of incorrect message is ', body);
            }
            
        }
        if (body.data) {
            body.data = JSON.parse(body.data);
        }
    }
    return body;
    
}

async function handleMessages(message) {
    try {
        if (!message) {
            throw 'No messages received';
        }
        let processedBody = processMessage(message);
        try {
            if (processedBody) {
                await MailEventController.insertMailEvent(processedBody);
                await deleteMessage(message);
                console.log('processMessage Success');
            }
            else {
                throw 'Unable to process message body';
            }
        }
        catch (error) {
            console.log(error);
        }
        console.log('handleMessages Success');
        return Promise.resolve();
    }
    catch (error) {
        console.log('handleMessages Error');
        console.log(error);
        return Promise.reject(error);
    }
}

exports.receiveMessages = async function (event,callback) {
    try {
        await receiveMessages(event);
        callback(null, 'DONE');
    }
    catch (error) {
        console.log('Error - ', error);
        callback(error);
    }
}