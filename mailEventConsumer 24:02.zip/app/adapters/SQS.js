const AWS = require("aws-sdk");
const sqs = new AWS.SQS({
    accessKeyId: process.env.ACCESS_KEY_ID,
    secretAccessKey: process.env.SECRET_ACCESS_KEY,
    region: process.env.AWS_REGION
});
class SQSAdapter {

    async receiveMessages(params) {
        const receiveMessagesPromise = new Promise((resolve, reject) => {
            sqs.receiveMessage(params, function (err, data) {
                if (err) {
                    console.error(err, err.stack);
                    reject(err);
                } else {
                    resolve(data.Messages);
                }
            });
        });
        try {
            const messages = await receiveMessagesPromise;
            return Promise.resolve(messages);
        }
        catch (error) {
            return Promise.reject(error);
        }
    };

    async deleteMessageBatch(params) {
        const deleteMessageBatchPromise = new Promise((resolve, reject) => {
            sqs.deleteMessageBatch(params, function (err, data) {
                if (err) {
                    console.error(err, err.stack);
                    reject(err);
                } else {
                    resolve(data);
                }
            });
        });
        try {
            const response = await deleteMessageBatchPromise;
            return Promise.resolve(response);
        }
        catch (error) {
            return Promise.reject(error);
        }
    }

    async deleteMessage(params) {
        const deleteMessagePromise = new Promise((resolve, reject) => {
            sqs.deleteMessage(params, function (err, data) {
                if (err) {
                    console.log(err, err.stack);
                    reject(err);
                }
                else {
                    resolve(data);
                }
            });
        });
        try {
            const response = await deleteMessagePromise;
            return Promise.resolve(response);
        }
        catch (error) {
            return Promise.reject(error);
        }
    }
}

module.exports = new SQSAdapter();