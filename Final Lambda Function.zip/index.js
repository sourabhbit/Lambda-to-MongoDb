

var MongoClient = require("mongodb").MongoClient

let db = null

var log = console.log.bind(console)

var print = function(object) {
    return JSON.stringify(object, null, 2)
}
//own code


// //end own code
// //const password = `notactuallyapassword`
const uri = `mongodb://developer:zvFB8d6L11r^lW@development-shard-00-00-czols.mongodb.net:27017,development-shard-00-01-czols.mongodb.net:27017,development-shard-00-02-czols.mongodb.net:27017/develop?ssl=true&replicaSet=Development-shard-0&authSource=admin&retryWrites=true&w=majority`;

exports.handler = function(event, context, callback) {
    log(`Calling MongoDB Atlas from AWS Lambda with event: ${print(event)}`)
    var obj = event;
    console.log(obj);
    //var store = obj.Records[0].body; // added
    
                                            //For all
                                          var messageId = obj.Records[0].messageId;
                                          var notificationType = JSON.parse(JSON.parse(obj.Records[0].body).Message).notificationType;
                                          //for mail
                                          var destination = JSON.parse(JSON.parse(obj.Records[0].body).Message).mail["destination"];
                                          var source = JSON.parse(JSON.parse(obj.Records[0].body).Message).mail.source;
                                          var sourceIp = JSON.parse(JSON.parse(obj.Records[0].body).Message).mail.sourceIp;
                                          var timestamp = JSON.parse(JSON.parse(obj.Records[0].body).Message).mail.timestamp;
                                          //bounce case variables
                                          
                                          

                                          if(JSON.parse(JSON.parse(obj.Records[0].body).Message).bounce){
                                          var bounceType = JSON.parse(JSON.parse(obj.Records[0].body).Message).bounce.bounceType;
                                          var bouncedRecipients = JSON.parse(JSON.parse(obj.Records[0].body).Message).bounce.bouncedRecipients[0].emailAddress; //emailaddress of bounced id
                                          var action = JSON.parse(JSON.parse(obj.Records[0].body).Message).bounce.bouncedRecipients[0].action;
                                          var status =JSON.parse(JSON.parse(obj.Records[0].body).Message).bounce.bouncedRecipients[0].status;
                                          var diagnosticCode = JSON.parse(JSON.parse(obj.Records[0].body).Message).bounce.bouncedRecipients[0].diagnosticCode;
                                          }
                                          //var myobj = { messageId: messageId, destination: destination, source: source, sourceIp: sourceIp, timestamp: timestamp, bounceType: bounceType, bouncedRecipients: bouncedRecipients, action: action, status: status};//added
                                          var myobj = { messageId: messageId, notificationType: notificationType, destination: destination, source: source, sourceIp: sourceIp, timestamp:timestamp, bounceType: bounceType, bouncedRecipients: bouncedRecipients, action: action, status: status, diagnosticCode: diagnosticCode };//added
                                          //var _myobj = {messageId: messageId}
    const databaseName = "develop",
        collectionName = "sourabh"

    context.callbackWaitsForEmptyEventLoop = false

    return createDoc(databaseName, collectionName, myobj)
}

async function createDoc(databaseName, collectionName, myobj) {
    var isConnected = db && db.serverConfig.isConnected()
    if (isConnected) {
        log(`Already connected to database ${databaseName}!`)
    } else {
        log(`Connecting to database (cold start)`)
        var client = await MongoClient.connect(uri)
        db = client.db(databaseName)
    }

    var result = await db.collection(collectionName).insertOne(myobj)
    log(`Just created an entry into ${collectionName} Collection with ID: ${result.insertedId}`)
    return result
}

// var obj={
//   "_id": {
//     "$oid": "5e4116e7b8fa8c0007ac8ec1"
//   },
//   "Records": [{
//     "messageId": "8d944eba-44c8-4b4c-9a44-d766afd6515f",
//     "receiptHandle": "AQEBU02M1QGejO76EJtw5SzXLwUAq3a5rq5j5O9pgasruSrO1DB/MYdXZYYzfU00mKzHQoP2Yig5kbIkLm9vmQY6rjtZ+CjlHJdO8NuG+97jbDF6C6OT/SKJXUR0siQdZm1rIdsPx7ICpMvYTHCY3x1VfV1J0V/8p34hHXvMcnzWo+BlXacMBrCgZP8zm1ByGyJ+lk4s6MvJje9qjoiczRsMXaIai/8ei3yv/QwqOC4jWPGXRKLmc5odgDFI2uh9KmMTqHTIGYFLs43Zv0g3k/eWT/M5/fg8+Y0PkU/RuawI8NJm+WdBLy078EMWOI0V80Lqfpy6bPvlidMlgC77lvp8YE69Q8H1I2EjNcS48JLKjRkgZod/fHOvvNBZWCTagbaB",
//     "body": {
//       "Type": "Notification",
//       "MessageId": "42eadb63-34f4-59f9-80e6-8dd82dd39854",
//       "TopicArn": "arn:aws:sns:us-east-1:044253371776:SES-Bounce-Notifications",
//       "Message": {
//         "notificationType": "Bounce",
//         "bounce": {
//           "bounceType": "Permanent ",
//           "bounceSubType": "General ",
//           "bouncedRecipients": [{
//             "emailAddress": "bounce @simulator.amazonses.com",
//             "action": "failed",
//             "status": "5.1 .1",
//             "diagnosticCode": "smtp;550 5.1 .1 user unknown"
//           }],
//           "timestamp": "2020-02-10T08:40:07.673Z",
//           "feedbackId": "010001702e4178c0-fd1a938a-fd0e-4537-93aa-d7a8fb58842f-000000",
//           "remoteMtaIp": "34.204.140.32",
//           "reportingMTA": "dsn; a48-121.smtp-out.amazonses.com"
//         },
//         "mail": {
//           "timestamp": "2020-02-10T08:40:07.000Z",
//           "source": "sport@bitdsports.in",
//           "sourceArn": "arn:aws:ses:us-east-1:044253371776:identity/bitdsports.in",
//           "sourceIp": "72.21.217.23",
//           "sendingAccountId": "044253371776",
//           "messageId": "010001702e41763d-6ca4ab23-4ec5-4d4e-9daf-4ce66ef7ae1c-000000",
//           "destination": "bounce@simulator.amazonses.com"
//         }
//       }
//     }
//   }]
// }
// //For all
// var messageId = obj.Records[0].messageId;
// var notificationType = obj.Records[0].body.Message.notificationType;
// //for mail
// var destination = obj.Records[0].body.Message.mail.destination;
// var source = obj.Records[0].body.Message.mail.source;
// var sourceIp = obj.Records[0].body.Message.mail.sourceIp;
// var timestamp = obj.Records[0].body.Message.mail.timestamp; 
// //bounce case variables
// var bounceType = obj.Records[0].body.Message.bounce.bounceType;
// var bouncedRecipients = obj.Records[0].body.Message.bounce.bouncedRecipients[0].emailAddress; //emailaddress of bounced id
// var action = obj.Records[0].body.Message.bounce.bouncedRecipients[0].action;
// var status =obj.Records[0].body.Message.bounce.bouncedRecipients[0].status;


// console.log("MessageId %s",messageId);







