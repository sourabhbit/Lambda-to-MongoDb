const AWS = require("aws-sdk");
const sqs = new AWS.SQS({
    accessKeyId: process.env.ACCESS_KEY_ID,
    secretAccessKey: process.env.SECRET_ACCESS_KEY,
    region: process.env.AWS_REGION
});
class SQSAdapter {

    async receiveMessages(params) {
        const receiveMessagesPromise = new Promise((resolve, reject) => {
            sqs.receiveMessage(params, function (err, data) {
                if (err) {
                    console.error(err, err.stack);
                    reject(err);
                } else {
                    console.log('inside success ', data);
                    resolve(data.Messages);
                }
            });
        });
        
        return await receiveMessagesPromise;
    };

}

module.exports = new SQSAdapter();