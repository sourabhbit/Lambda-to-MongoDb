const AWS = require('aws-sdk');
const lambda = new AWS.Lambda({
    accessKeyId: process.env.ACCESS_KEY_ID,
    secretAccessKey: process.env.SECRET_ACCESS_KEY,
    region: process.env.AWS_REGION
});

class lambdaAdapter {

    invokeWorkerLambda(payload,callback) {
        let params = {
            FunctionName: process.env.WORKER_LAMBDA_NAME,
            InvocationType: 'Event',
            Payload: JSON.stringify(payload)
        };
        lambda.invoke(params, function (err, data) {
            if (err) {
                console.log('Lambda invoke error');
                console.error(err, err.stack);
                callback(err);
            } else {
                console.log('Lambda invoke success');
                console.log(data);
                callback(null, data);
            }
        });
    }

}

module.exports = new lambdaAdapter();