const async = require('async');
const lambdaAdapter = require('./adapters/lambda');
const SQSAdapter = require('./adapters/SQS');
const TASK_QUEUE_URL = process.env.TASK_QUEUE_URL;
const LAMBDA_EXECUTION_TIMEOUT = process.env.LAMBDA_EXECUTION_TIMEOUT;

async function receiveMessages(callback) {
    var params = {
      QueueUrl: TASK_QUEUE_URL,
      MaxNumberOfMessages: 10
    };
    try {
        const messages = await SQSAdapter.receiveMessages(params);
        //console.log('messages length is ', messages.length);
        callback(null, messages);
    } catch (error) {
        console.log(error);
        callback(error);
    }
  }

async function handleSQSMessages(context, callback) {
    receiveMessages(function(err, messages) {
      if(err){
        console.error(err);
      } else if (messages) {
          console.log('inside messages lenght');
            let invocations = [];
            messages.forEach(function(message) {
                invocations.push(function (callback) {
                    lambdaAdapter.invokeWorkerLambda(message, callback);
                    console.log("invokeWorker UP");
                });
            });
            async.parallel(invocations, function(err) {
            if (err) {
                console.error(err, err.stack);
                callback(err);
            } else {
                if (context.getRemainingTimeInMillis() > LAMBDA_EXECUTION_TIMEOUT) {
                handleSQSMessages(context, callback); 
                } else {
                callback(null, 'PAUSE');
                }         
            }
            });
        } else {
            callback(null, 'DONE');
            console.log("HandleSQS UP");
        }
    });
  }

exports.invokeWorkers = function (context, callback) {
    handleSQSMessages(context, callback);
}