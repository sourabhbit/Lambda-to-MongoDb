const { invokeWorkers } = require('./app/controller');

exports.handler = function (event, context, callback) {
    context.callbackWaitsForEmptyEventLoop = false;
    invokeWorkers(context,callback);
};